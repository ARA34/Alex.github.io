function setup() {
  createCanvas(200, 200);
}

function draw() {
  background(1000);
  
  
  strokeWeight(4)
  fill(255,0,0)
  rect(0,100,50,50)
  
  strokeWeight(4)
  fill(255,0,0)
  rect(100,100,20,50)
  
  strokeWeight(4)
  fill(0,0,128)
  rect(0,0,100,50)
  
  strokeWeight(4)
  fill(0,0,128)
  rect(148,0,50,50)
  
  strokeWeight(4)
  fill(255,255,0)
  rect(100,0,50,100)
  
  strokeWeight(4)
  fill(255,255,0)
  rect(150,100,50,100)
  
  strokeWeight(4)
  fill(0,0,128)
  rect(0,150,100,100)
  
  strokeWeight(4)
  fill(1000)
  rect(100,150,50,50)
  
    
  strokeWeight(4)
  fill(255,0,0)
  rect(0,50,75,50)
  
      
  strokeWeight(4)
  fill(1000)
  rect(50,100,50,50)
  
  strokeWeight(4)
  fill(1000)
  rect(50,100,50,50)
}